<?php
$site='http://localhost/elibrary/';
$img_path='../images/';

$vehicle_path='http://localhost/dl/vehicle.php';


?>

