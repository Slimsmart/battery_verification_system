<?php
define('DB_SERVER', 'localhost');
define('DB_NAME', 'career_g');
define('DB_USER', 'root');
define('DB_PASSWORD', '');

?>

